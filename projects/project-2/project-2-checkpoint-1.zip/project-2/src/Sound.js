export default class Sound
{
    constructor(id, url)
    {
        Object.assign(this, { id, url });
    }
}